```sh
npm install --save react-google-maps # or
yarn add react-google-maps
```
